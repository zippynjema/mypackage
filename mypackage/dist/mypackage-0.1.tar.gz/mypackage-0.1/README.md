# mypackage
This library was created as an example of how to publish your oown python package

## Building this package locally
## 'python setup.py sdist'

## Installing this package from github
## 'pip install git+https://github.com/zippynjema/mypackage.git'

## updating this package fro Github
## 'pip install --upgrade git+https://github.com/zippynjema/mypackage'